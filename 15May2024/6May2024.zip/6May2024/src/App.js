import CRUDComponent from './Components/CRUDComponent';
import CounterComponent from './Components/CounterComponent';

function App() {
  return (
    // <CounterComponent />
    <CRUDComponent/>
  )
}

export default App;
