import CRUDComponent from './Components/CRUDComponent';
import CounterComponent from './Components/CounterComponent';
import CounterComponentRed from './Components/CounterComponentRed';
import FocusInput from './Components/FocusInput';
import FocusInputLayout from './Components/FocusInputLayout';
import { CounterComp } from './Components/MemoizationComponents'
function App() {
  return (
    // <CounterComponent />
    // <CRUDComponent/>
    // <CounterComponentRed />
    // <CounterComp />
    // <FocusInput/>
    <FocusInputLayout/>
  )
}

export default App;
